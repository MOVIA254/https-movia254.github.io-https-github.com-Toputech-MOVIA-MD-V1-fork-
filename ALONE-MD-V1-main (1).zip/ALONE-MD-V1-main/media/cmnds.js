
//clone at your own risk🚫



































conf{toputech.urls}conf.cmnds+attach,all-cmnds ={_dirname.../commandes}*150+cmndlengh
//thankyou chat gpt 
sync (gpt4premium)+data conversation 
