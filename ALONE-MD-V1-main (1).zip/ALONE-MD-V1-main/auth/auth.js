//..
sync toputech.urls
fetch {alone md*150+cmdlength}
