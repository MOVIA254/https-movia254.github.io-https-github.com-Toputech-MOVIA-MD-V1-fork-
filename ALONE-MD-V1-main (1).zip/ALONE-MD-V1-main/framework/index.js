"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.genererNomFichier = exports.stick = exports.format = exports.styletext = exports.zJson = exports.getBuffer = exports.reaction = exports.police = exports.zokou = void 0;
let { zokou } = require("./zokou");
exports.zokou = zokou;
const mesfonctions_1 = require("./mesfonctions");
Object.defineProperty(exports, "reaction", { enumerable: true, get: function () { return mesfonctions_1.reaction; } });
Object.defineProperty(exports, "police", { enumerable: true, get: function () { return mesfonctions_1.police; } });
Object.defineProperty(exports, "getBuffer", { enumerable: true, get: function () { return mesfonctions_1.getBuffer; } });
Object.defineProperty(exports, "zJson", { enumerable: true, get: function () { return mesfonctions_1.zJson; } });
Object.defineProperty(exports, "format", { enumerable: true, get: function () { return mesfonctions_1.format; } });
Object.defineProperty(exports, "styletext", { enumerable: true, get: function () { return mesfonctions_1.styletext; } });
Object.defineProperty(exports, "stick", { enumerable: true, get: function () { return mesfonctions_1.stick; } });
Object.defineProperty(exports, "genererNomFichier", { enumerable: true, get: function () { return mesfonctions_1.genererNomFichier; } });
var { reagir } = require("./app");

